﻿using UnityEngine;
using System.Collections;

public class PlayDeathSound : MonoBehaviour {

	// Use this for initialization
	public AudioSource deathSource;
	void Start () {
		deathSource = gameObject.AddComponent<AudioSource>();
		deathSource.clip = Resources.Load("Sounds/Death") as AudioClip;
		deathSource.volume = .2f;
		deathSource.Play ();
	}
	
	// Update is called once per frame
	void Update () {
	
	}
}
