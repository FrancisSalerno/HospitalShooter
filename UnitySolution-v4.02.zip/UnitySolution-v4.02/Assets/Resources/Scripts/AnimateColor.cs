﻿using UnityEngine;
using System.Collections;

public class AnimateColor : MonoBehaviour {

	// Use this for initialization
	void Start () {
	
	}
	
	// Update is called once per frame
	void Update () {
		SpriteRenderer render = GetComponent<SpriteRenderer>();
		if (Input.GetMouseButton (0)) {
			render.color = Color.red;
		} else {
			render.color = new Color(255,255,255);
		}
	}
}
