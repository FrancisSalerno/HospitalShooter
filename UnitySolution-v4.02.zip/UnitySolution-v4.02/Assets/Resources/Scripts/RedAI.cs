﻿using UnityEngine;
using System.Collections;

public class RedAI : MonoBehaviour {
	// Use this for initialization
	public Vector3 startPosition;
	public float speed;
	public float timeAlive;
	void Start () {
		transform.position = startPosition;
	}
	// Update is called once per frame
	void Update () {
		Destroy (gameObject, timeAlive);
		transform.Translate(new Vector3(speed,0,0));
	}
}
