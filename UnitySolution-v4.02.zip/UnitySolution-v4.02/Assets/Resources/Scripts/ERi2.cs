﻿using UnityEngine;
using System.Collections;


public class ERi2 : MonoBehaviour {

	Vector3 pointA;
	Vector3 pointB;
	
	IEnumerator Start()
	{
		pointA = new Vector3(randNumSide(),30f,0f);
		pointB = new Vector3(randNumSide(),-28f,0f);
		while (true) {

			yield return StartCoroutine(MoveObject(transform, pointA, pointB, randNumSpeed()));
			pointA = new Vector3(randNumSide(), 30f,0f);

			yield return StartCoroutine(MoveObject(transform, pointB, pointA, randNumSpeed ()));
			pointB = new Vector3(randNumSide(),-28f,0f);
		}
	}
	
	IEnumerator MoveObject(Transform thisTransform, Vector3 startPos, Vector3 endPos, float time)
	{
		var i= 0.0f;
		var rate= 1.0f/time;
		while (i < 1.0f) {
			i += Time.deltaTime * rate;
			thisTransform.position = Vector3.Lerp(startPos, endPos, i);
			yield return null; 
		}
	}

	float randNumSpeed(){
		return Random.Range (1.5f, 5.0f);
	}

	float randNumSide(){
		return Random.Range (-51.0f, 52.0f);
	}

}
