﻿using UnityEngine;
using System.Collections;

public class MoveScript : MonoBehaviour {

	// Use this for initialization
	public float baseSpeed = 100f;
	public float shiftMultiplier = 2.5f;
	Vector3 player_pos;
	Vector3 player_pos_s;
	Vector2 lastMouse;
	void Start () {
	
	}
	
	// Update is called once per frame
	void Update () {
	//-----	player_pos = this.transform.position;//grab the position of the player relative to the game world position
		//grab the position of the player relative to the screen
		player_pos_s = Camera.mainCamera.WorldToScreenPoint(transform.position);
		//updateJoystick ();
		updateKeyboard ();
	}
	void updateKeyboard(){
		Vector2 currentForce = new Vector2 (0, 0);
	
		if (player_pos_s.x < 0)//multiplies 2.5 to the base force to make the play stay on screen
			currentForce.x += 2.5f * baseSpeed;
		if (player_pos_s.x > Screen.width)//multiplies 2.5 to the base force to make the play stay on screen
			currentForce.x -= 2.5f * baseSpeed;
		if (player_pos_s.y < 0)//multiplies 2.5 to the base force to make the play stay on screen
			currentForce.y += 2.5f * baseSpeed;
		if (player_pos_s.y > Screen.height)//multiplies 2.5 to the base force to make the play stay on screen
			currentForce.y -= 2.5f * baseSpeed;


		if (Input.GetKey (KeyCode.A))
			currentForce.x -= baseSpeed;
		if (Input.GetKey (KeyCode.D))
			currentForce.x += baseSpeed;
		if (Input.GetKey (KeyCode.S))
			currentForce.y -= baseSpeed;
		if (Input.GetKey (KeyCode.W))
			currentForce.y += baseSpeed;

		if (Input.GetKey (KeyCode.LeftShift)) {
			currentForce.x *= shiftMultiplier;
			currentForce.y *= shiftMultiplier;
		}
		gameObject.rigidbody2D.AddForce (currentForce , ForceMode2D.Force);
		gameObject.rigidbody2D.drag = 8f;




		Vector3 playerToMouse;
		Vector3 inputPosition = Input.mousePosition; 

		Vector3 launchTowards = GameObject.Find ("Reticule").GetComponent<Transform> ().position;
		float varX = launchTowards.x - transform.position.x;
		float varY = launchTowards.y - transform.position.y;
		
		Vector3 launchDirection = new Vector3 (varX, varY);
		
		float angleRadians = Mathf.Atan2 (varY, varX);
		
		float angleDegrees = (angleRadians * Mathf.Rad2Deg);
		
		if (angleDegrees < 0) {
			angleDegrees += 360;
		}
		
		transform.eulerAngles = new Vector3 (0, 0, angleDegrees);
	/*	Vector3 mouseWorldPosition = Camera.main.ScreenToWorldPoint
			(new Vector3 (Screen.width - inputPosition.x,
			              Screen.height - inputPosition.y, 
			              Camera.main.transform.position.z - 2f));


			

	
		mouseWorldPosition.z = 10;
		float AngleRad = Mathf.Atan2(mouseWorldPosition.y - transform.position.y, mouseWorldPosition.x - transform.position.x);
		float AngleDeg = (180 / Mathf.PI) * AngleRad;
		this.transform.rotation = Quaternion.Euler(0, 0, AngleDeg);

		float x = Input.GetAxis ("RightX");
		float y = Input.GetAxis ("RightY");
		if (Input.GetKeyUp(KeyCode.E)) {
			Debug.Log ("X axis = " + x);
			Debug.Log ("Y Axis = " + y);
		}*/
		/*float rotate_x = 0;
		float rotate_y = 0;

		rotate_x = lastMouse.x - inputPosition.x;
		rotate_y = lastMouse.y - inputPosition.y;

		transform.eulerAngles += new Vector3 (0, 0, rotate_x / rotate_y); */
	/*	if (transform.eulerAngles.z < 0) {
			transform.eulerAngles += new Vector3(0,0,360);
		}*/
		lastMouse = inputPosition;

	}
	void updateJoystick(){	
		Vector2 currentForce = new Vector2 (0, 0);
		currentForce.x += Input.GetAxis ("Horizontal") * baseSpeed;
		currentForce.y += Input.GetAxis ("Vertical") * baseSpeed;
		if (Input.GetAxis ("LeftTrigger") != 0) {
				currentForce.x *= shiftMultiplier;
				currentForce.y *= shiftMultiplier;
		}
		gameObject.rigidbody2D.AddForce (currentForce, ForceMode2D.Force);
		gameObject.rigidbody2D.drag = 8f;
	}
}
