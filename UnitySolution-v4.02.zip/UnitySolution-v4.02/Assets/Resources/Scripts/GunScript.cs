using UnityEngine;
using System.Collections;

public class GunScript : MonoBehaviour
{

	const int LEFTCLICK = 0;

	public bool isShooting = false;
	public bool usingKeyboard = true;
	public bool usingJoystick = false;
	//NOTE: The bulletSpeed should be 5,000 times as much as the push force for proper movement!
	public float bulletSpeed = 250f;//how fast the bullet travels
	public float mass = .05f;//adjusts the mass of the bullet, aka the knockback of the bullet
	public float fireRate = .05f;

	public AudioSource gunSource;

		// Use this for initialization
		void Awake ()
		{
			gunSource = gameObject.AddComponent<AudioSource>();
			gunSource.clip = Resources.Load("Sounds/GunShoot") as AudioClip;
			gunSource.volume = .2f;
	
		}
	void Start(){
		InvokeRepeating ("Shoot", 0.0001f, .08f);		//Invoke repeating bug. http://answers.unity3d.com/questions/465034/invokerepeating-doesnt-really-care-about-repeat-ti.html Source		
														//Second argument can't be 0
	}

	void Shoot(){
		if (isShooting) {
			GameObject bulletInstance = Instantiate(Resources.Load("Player/BulletPrefab")) as GameObject;
			bulletInstance.rigidbody2D.mass = mass;

			gunSource.Play();

			//this next line is uneeded if the 2D physics manager settings are correct
			//and the layers are set
			//Physics2D.IgnoreCollision (bulletInstance.collider2D , this.gameObject.collider2D);//ignore collisions between this object and bullets
			
			bulletInstance.transform.position = gameObject.transform.position;//set the position of the bullet
			bulletInstance.transform.eulerAngles = gameObject.transform.eulerAngles;//set the angle of the bullet
			//bulletInstance.AddComponent<WhenToDestroy>();
			
			Vector3 force =  Quaternion.AngleAxis(gameObject.transform.eulerAngles.z,Vector3.forward) * Vector3.right;//find the force of the bullet

			//force.Normalize();//normalize the force
			force.x *= bulletSpeed;//set the x force of the bullet
			force.y *= bulletSpeed;//set the y force of the bullet
			bulletInstance.rigidbody2D.AddForce(force);//apply the force to the bulletInstance
		}
	}
	void Update(){ 

		if (usingKeyboard) 
		{
			isShooting = Input.GetMouseButton (LEFTCLICK);
			if (isShooting) 
			{

				//UpdateMouse ();
			}
		} 
		else 
		{			

			float x = Input.GetAxis("RightX");
			float y = Input.GetAxis("RightY");
			UpdateJoystick(x,y);
			isShooting = (Mathf.Abs(x) > 0.40f || Mathf.Abs(y) > 0.40f);
		


		
		}
	}
	void UpdateJoystick(float x, float y){
		float angle = Mathf.Atan2(y, x) * Mathf.Rad2Deg; 
		if (angle < 0) {
			angle += 360;
		}
		transform.rotation = Quaternion.Euler(new Vector3(0,0,  angle));
	}

}