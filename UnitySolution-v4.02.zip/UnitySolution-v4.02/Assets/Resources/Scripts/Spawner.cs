﻿using UnityEngine;
using System.Collections;

public class Spawner : MonoBehaviour {
	static int[] enemyNames;
	static int totalEnemies;
	static int MAXTOTALENEMIES = 500;
	
	public int maxEnemies = 10;
	public int spawnRate = 5;
	public float initialDelay = 3;
	public GameObject enemyType;
	
	private GameObject[] enemies;
	private int[] enemyNumbers;
	private int currentEnemies = 0;
	
	void Start () {
		enemyNames = new int[MAXTOTALENEMIES];
		for(int i=0; i<MAXTOTALENEMIES; i++) {
			enemyNames[i] = i;
		}
		
		enemyNumbers = new int[maxEnemies];
		enemies = new GameObject[maxEnemies];
		
		for(int i=0; i<maxEnemies; i++) {
			enemyNumbers[i] = i;
		}

		StartCoroutine (initialWait ());
	}

	IEnumerator initialWait() {
		yield return new WaitForSeconds (initialDelay);
		InvokeRepeating ("Spawn", .0001f, spawnRate);
	}

	
	void Spawn(){
		if(currentEnemies < maxEnemies && totalEnemies < MAXTOTALENEMIES) {
			for(int i=0; i<maxEnemies; i++) {
				if(enemyNumbers[i] == i) {
					enemies[i] = Instantiate((GameObject)Resources.Load("Enemies/" + enemyType.gameObject.name)) as GameObject;//respawn
					enemies[i].transform.position = this.transform.position;
					
					//set the enemy name
					for(int j=0; j<MAXTOTALENEMIES; j++) {
						if(enemyNames[j] != -1) {//extract the first name available
							enemies[i].name = enemyNames[j].ToString ();
							enemyNames[j] = -1;
							j = MAXTOTALENEMIES;//exit the for loop
						}
					}
					
					
					enemies[i].AddComponent<Decrement> ();
					Decrement script = enemies[i].GetComponent<Decrement> ();
					script.spawner = this.gameObject;
					script.spawnNumber = currentEnemies;
					IncrementEnemy ();
					
					enemyNumbers[i] = -1;//flag stating that this enemy slot is taken
					
					i=maxEnemies;
				}
			}
		}
	}
	// Update is called once per frame
	void Update () {
		
	}
	public void IncrementEnemy(){
		totalEnemies ++;
		currentEnemies ++;
	}
	public void DecrementEnemy(int enemyNumber){
		totalEnemies --;
		currentEnemies --;
		enemyNumbers [enemyNumber] = enemyNumber;
	}
}