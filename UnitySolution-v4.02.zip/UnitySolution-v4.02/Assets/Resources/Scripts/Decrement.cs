﻿using UnityEngine;
using System.Collections;

public class Decrement : MonoBehaviour {
	
	public GameObject spawner;
	public int spawnNumber;
	public int spawnName;
	private EnemyDescription enemScript;
	
	void Start() {
		enemScript = this.gameObject.GetComponent<EnemyDescription> ();

	}
	
	void Update() {
		if (enemScript.isDead) {
			Spawner spawnScript = spawner.GetComponent<Spawner> ();
			spawnScript.DecrementEnemy(spawnNumber);
			Destroy (this);
		}
	}
}