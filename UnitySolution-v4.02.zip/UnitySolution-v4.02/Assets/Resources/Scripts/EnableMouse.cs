﻿using UnityEngine;
using System.Collections;

public class EnableMouse : MonoBehaviour {

	// Use this for initialization
	void Start () {
		Screen.showCursor = true;
	}
}
