﻿using UnityEngine;
using System.Collections;

public class EnemyDescription : MonoBehaviour {

	public float pushForce = 5f;//how far the player is pushed back when attacked by the enemy
	public int attackDamage = 1;//how much damage is dealt to the player when attacked
	public int health = 10;//how much health the enemy has
	public bool takeImpactDamage = false;//does the enemy take damage upon colliding with the player?
	public bool friendlyFire = false;
	public bool isDead = false;//boolean if the character is dead, it is true
	public float mass = 3f;//how much the object weighs
	public float delayedDeath = .5f;//how long the enemy lingers after dieing
	public AudioSource deathSound;
	public float pickupProbability = 5f; //How likely it is that we will drop an item (percentage)



	void Start(){
		renderer.material.color = Color.green;
		if (pickupProbability > 100) {
			pickupProbability = 100;
		} else if (pickupProbability < 0) {
			pickupProbability = 0;
		}
	}
	void Awake() {
		this.rigidbody2D.mass = mass;
		//renderer.material.color = Color.green;
		deathSound = gameObject.AddComponent<AudioSource>();
		deathSound.clip = Resources.Load("Sounds/Hit4") as AudioClip;
		deathSound.volume = .3f;
	}

	public void takeDamage(int dmg) {
		//do nothing if isDead is true 
		if (isDead) {
			return;
		}
		ChangeColor ();
		health -= dmg;
		if (health < 0) {
			Death();
		}
	}

	void ChangeColor(){
		Color current = renderer.material.color;
		renderer.material.color = current + new Color (.2f, -.1f, 0);

	}

	void OnCollisionEnter2D(Collision2D col){
		if (col.gameObject == GameObject.Find ("Player")) {
			col.gameObject.GetComponent<PlayerHealth>().takeDamage(attackDamage);
		} else if (friendlyFire && col.gameObject.tag == "Enemy") {
			col.gameObject.GetComponent<EnemyDescription>().takeDamage(attackDamage);
		}
	}

	public void Death() {
		SpawnHealthPickup ();
		deathSound.Play ();
		renderer.material.color = Color.grey;

		isDead = true;
		//destroyes the collider to ignore bullets upon dieing
		Destroy (this.gameObject.collider2D);
		
		Destroy (this.gameObject, delayedDeath);//deletes the gameObject after delayedDeath seconds
		
		//GameObject newEnemy = Instantiate(Resources.Load("Prefabs/EnemyPrefab")) as GameObject;//respawns a new enemy
	}
	void SpawnHealthPickup(){
		if (Random.Range (0f, 100f) <= pickupProbability) {
			GameObject pic = Instantiate((GameObject)Resources.Load("Pickups/HealthPickup")) as GameObject;
			pic.transform.position = transform.position;
		}
	}
}