﻿using UnityEngine;
using System.Collections;

public class HealthPickupDescription : MonoBehaviour {

	// Use this for initialization

	int randomValue;
	int points;
	AudioSource soundOnPickup;
	
	void Start () {

		randomValue = Random.Range (0, 3);
		switch (randomValue) {
		case 0:
			soundOnPickup = gameObject.AddComponent<AudioSource>();
			soundOnPickup.clip = Resources.Load("Sounds/powerup_2") as AudioClip;
			soundOnPickup.volume = .1f;
			points = 10;
			break;
		case 1:
			soundOnPickup = gameObject.AddComponent<AudioSource>();
			soundOnPickup.clip = Resources.Load("Sounds/powerup_3") as AudioClip;
			soundOnPickup.volume = .1f;
			points = 25;
			break;
		case 2: 
			soundOnPickup = gameObject.AddComponent<AudioSource>();
			soundOnPickup.clip = Resources.Load("Sounds/powerup") as AudioClip;
			soundOnPickup.volume = .1f;
			points = 100;
			break;
		default:
			points = 0;
			break;
			
		}
	}
	// Update is called once per frame
	void Update () {
		switch (randomValue) {
		case 0:
			Destroy(gameObject,10);
			transform.Rotate (new Vector3 (0, 0, 2));
			break;
		case 1:
			Destroy(gameObject,5);
			transform.Rotate (new Vector3 (0, 0, 10));
			break;
		case 2:
			Destroy(gameObject,3);
			transform.Rotate (new Vector3 (0, 0, 20));
			break;
		}
	}
	void OnCollisionEnter2D(Collision2D col){
		if (col.gameObject == GameObject.Find ("Player")) {
			col.gameObject.GetComponent<PlayerHealth>().addHealth(points);
			AudioSource.PlayClipAtPoint(soundOnPickup.clip,Vector3.zero, 1.0f);
		}
		Destroy (gameObject);
	}
}
