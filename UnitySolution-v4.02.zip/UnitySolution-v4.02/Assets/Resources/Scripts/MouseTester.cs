﻿using UnityEngine;
using System.Collections;

public class MouseTester : MonoBehaviour {

	// Use this for initialization
	Vector3 lastMouse;
	void Start () {
		transform.position = new Vector3 (0, 0, 0);
	}
	
	// Update is called once per frame
	void Update () {


	
		Vector3 mouseWorld = Camera.main.ScreenToWorldPoint 
			(new Vector3 (Input.mousePosition.x, Input.mousePosition.y, -10));

		mouseWorld.z = 0;
		Vector3 difference = lastMouse - mouseWorld;
		transform.position += difference;

	
		lastMouse = mouseWorld;
	}

	void UpdateGamePad(){
		Vector3 mouseWorld = Camera.main.ScreenToWorldPoint 
			(new Vector3 (Input.mousePosition.x, Input.mousePosition.y, -10));
		
		mouseWorld.z = 0;
		Vector3 difference = lastMouse - mouseWorld;
		transform.position += difference;
		
		
		lastMouse = mouseWorld;
	}
}
