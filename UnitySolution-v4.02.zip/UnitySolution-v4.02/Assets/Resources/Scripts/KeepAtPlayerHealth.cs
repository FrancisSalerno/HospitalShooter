﻿using UnityEngine;
using System.Collections;

public class KeepAtPlayerHealth : MonoBehaviour {

	// Use this for initialization
	int Playerhealth;
	Vector3 playerPosition;
	void Start () {
	
	}
	
	// Update is called once per frame
	void Update () {

		Playerhealth = GameObject.Find ("Player").GetComponent<PlayerHealth> ().health;
		playerPosition = GameObject.Find ("Player").GetComponent<Transform> ().position;

		transform.position = new Vector3 (playerPosition.x , playerPosition.y + 4, -.1f);
		transform.localScale = new Vector3 (Playerhealth / 10, 1, .1f);

		gameObject.renderer.material.color = GameObject.Find ("Player").GetComponent<ParticleSystem> ().startColor;


	}
}
