﻿using UnityEngine;
using System.Collections;

public class SimpleFollow : MonoBehaviour {

	// Use this for initialization
	float speed = 1.0f;
	float force = 50;
	void Start () {
		gameObject.rigidbody2D.drag = 2;
	}
	
	// Update is called once per frame
	void Update () {
		if (this.gameObject.GetComponent<EnemyDescription>().isDead)//stop moving if dead
			return;

		if (gameObject.transform.position.x < GameObject.Find ("Player").transform.position.x) {
				rigidbody2D.AddForce (new Vector3 (force, 0, 0));
		} else {
				rigidbody2D.AddForce (new Vector3 (-force, 0, 0));
		}
		if (gameObject.transform.position.y < GameObject.Find ("Player").transform.position.y) {
			rigidbody2D.AddForce (new Vector3 (0, force, 0));
		} else {
			rigidbody2D.AddForce (new Vector3 (0, -force, 0));
		}

		LookAtPlayer ();
	}

	void LookAtPlayer() {
		Vector3 playerPos = GameObject.Find ("Player").transform.position;
		Vector3 objPos = this.transform.position;

		float varX = playerPos.x - objPos.x;
		float varY = playerPos.y - objPos.y;

		
		float angleRadians = Mathf.Atan2 (varY, varX);
		
		float angleDegrees = (angleRadians * Mathf.Rad2Deg);
		
		if (angleDegrees < 0) {
			angleDegrees += 360;
		}

		transform.eulerAngles = new Vector3 (0, 0, angleDegrees);
	}
}
