﻿using UnityEngine;
using System.Collections;
using System;

public class LookLaunch : MonoBehaviour {

	// Use this for initialization
	bool Launched;
	bool canShoot = true;
	Vector3 launchDirection;
	float speed = 50f;
	const float MAXSPEED = 120;
	float waitTime = 3f;
	void Start () {
		Launched = false;
		waitTime = 3f;
		speed = 50f;
	}
	
	// Update is called once per frame
	void Update () {
		if (!Launched) {
			if (canShoot) {
				gameObject.GetComponent<EnemyDescription>().attackDamage += 4;
				LookAtPlayer ();
				launchDirection.Normalize ();
				launchDirection *= speed;
				launchDirection.z = 0;
				gameObject.rigidbody2D.velocity = launchDirection;
				Launched = true;
			}

		} else {
			stickBall();
		}
			
	}
	void stickBall(){
		Vector3 screenWorldPos = Camera.mainCamera.WorldToScreenPoint(transform.position);


		float half_sz = gameObject.renderer.bounds.size.x/2;
		float half_sz_Y = gameObject.renderer.bounds.size.y/2;
		if (screenWorldPos.x < (0 + half_sz )
			|| screenWorldPos.y < (0 + half_sz_Y)
			|| screenWorldPos.y > (Screen.height - half_sz_Y )
			|| screenWorldPos.x > (Screen.width - half_sz)) {
		
				StartCoroutine(waitToShoot());
				gameObject.rigidbody2D.velocity = new Vector2 (0, 0);
				LookAtPlayer ();
				Launched = false;


				
					
				Vector3 wrldRight = Camera.mainCamera.ScreenToWorldPoint(new Vector3((float)Screen.width,screenWorldPos.y, 10.0f));
				Vector3 wrldLeft = Camera.mainCamera.ScreenToWorldPoint(new Vector3(0.0f, screenWorldPos.y, 10.0f));
				Vector3 wrldTop = Camera.mainCamera.ScreenToWorldPoint(new Vector3(screenWorldPos.x, (float)Screen.height, 10.0f));
				Vector3 wrldBottom = Camera.mainCamera.ScreenToWorldPoint(new Vector3(screenWorldPos.x, 0.0f, 10.0f));

		/*		Debug.Log("right " + wrldRight);
				Debug.Log("left " + wrldLeft);
				Debug.Log("up " + wrldTop);
				Debug.Log("down " + wrldBottom);*/
				if(transform.position.x > (wrldRight.x - half_sz))
				{
					Debug.Log("position before"+transform.position);
					transform.position = new Vector3(wrldRight.x -half_sz, transform.position.y);
					Debug.Log(transform.position);
				}
				if(transform.position.x < (wrldLeft.x + half_sz))
				{
					transform.position = new Vector3(wrldLeft.x + half_sz, transform.position.y);
				}
				if(transform.position.y > (wrldTop.y - half_sz_Y))
				{
					transform.position = new Vector3(transform.position.x, wrldTop.y - half_sz_Y);
				}
				if(transform.position.y < (wrldBottom.y + half_sz_Y))
				{
					transform.position = new Vector3(transform.position.x,  wrldBottom.y + half_sz_Y);
				}

				
				if (MAXSPEED > speed) {
					speed += 10;
				}
		}

	}

	IEnumerator waitToShoot()
	{
		// do stuff before waitTime
		canShoot = false;
		if (waitTime > 0)
			yield return new WaitForSeconds(waitTime);
		canShoot = true;
		// do stuff after waitTime
	}
	void OnCollisionEnter2D(Collision2D collider){
		if (collider.gameObject == GameObject.Find ("Player")) {
			//ApplyDamage
		}
	}

	void LookAtPlayer() {
		Vector3 playerPos = GameObject.Find ("Player").transform.position;
		Vector3 objPos = this.transform.position;
		
		float varX = playerPos.x - objPos.x;
		float varY = playerPos.y - objPos.y;

		launchDirection = new Vector3 (varX, varY);
		
		float angleRadians = Mathf.Atan2 (varY, varX);
		
		float angleDegrees = (angleRadians * Mathf.Rad2Deg);
		
		if (angleDegrees < 0) {
			angleDegrees += 360;
		}
		
		transform.eulerAngles = new Vector3 (0, 0, angleDegrees);
	}
}
