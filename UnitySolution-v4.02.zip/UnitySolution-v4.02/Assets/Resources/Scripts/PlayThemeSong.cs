﻿using UnityEngine;
using System.Collections;

public class PlayThemeSong : MonoBehaviour {

	// Use this for initialization
	public AudioSource themeStart;
	AudioSource themeLoopEnd;
	bool startLoop = false;
	void Start () {
		themeStart = gameObject.AddComponent<AudioSource>();		//Load the theme song into memory
		themeStart.clip = Resources.Load("Sounds/MainThemeBeg") as AudioClip;
		themeStart.volume = 1f;

		themeLoopEnd = gameObject.AddComponent<AudioSource> ();		//This is put on repeat 
		themeLoopEnd.clip = Resources.Load ("Sounds/MainThemeEnd") as AudioClip;
		themeLoopEnd.volume = 1f;
		themeLoopEnd.loop = true;



		themeStart.Play ();
	}
	
	// Update is called once per frame
	void Update () {
		if (!themeStart.isPlaying  && startLoop == false) {		//After the intro finishes 
			startLoop = true;									//make sure we don't play every frame
			themeLoopEnd.Play();								//play the looped portion
		}
	}
}
