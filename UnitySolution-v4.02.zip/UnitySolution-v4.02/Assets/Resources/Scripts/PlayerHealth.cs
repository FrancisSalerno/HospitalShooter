﻿using UnityEngine;
using System.Collections;

public class PlayerHealth : MonoBehaviour {

	// Use this for initialization
	public int health = 100;
	bool isInvincible = false;
	int gracePeriod = 1; // one second

	void Start () {
	
	}
	
	// Update is called once per frame
	public void takeDamage(int damage){
		//gameObject.GetComponent<ParticleSystem> ().startColor = Color.Lerp (Color.red, Color.green, (float)health / 100);
		//gameObject.GetComponent<ParticleSystem> ().startColor = Color.Lerp (Mathf.PingPong ((float)health / 100.0), Color.red, Color.green);
		if (!isInvincible) {
			health -= damage;
			StartCoroutine(startInvincible());
		}
		if (health < 0) {
			health = 0;
			Application.LoadLevel(1);
			Debug.Log("Loading Replay Level");
		}
	}

	public void addHealth(int addhealth){
		health += addhealth;
		if (health > 100) {
			health = 100;
		}
	}



	IEnumerator startInvincible()
	{
		// do stuff before waitTime
		isInvincible = true;
		if (gracePeriod > 0)
			yield return new WaitForSeconds(gracePeriod);
		isInvincible = false;
		// do stuff after waitTime
	}
	void Update () {
		gameObject.GetComponent<ParticleSystem> ().startColor = Color.Lerp (Color.red,Color.green, (float)health / 100);
		if (health > 100) {
			health = 100;
		}
		if (health < 0) {
			health = 0;
			Application.LoadLevel(1);
			Debug.Log("Loading Replay Level");
		}
	}
}
