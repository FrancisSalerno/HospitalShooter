﻿using UnityEngine;
using System.Collections;

public class EnemyDescription : MonoBehaviour {
	public int startingHealth = 10;
	public int damage = 1;
	private int currentHealth;
	public bool isDead;

	void Awake() {
		currentHealth = startingHealth;
		isDead = false;
	}

	public void takeDamage(int dmg) {
		//do nothing if isDead = true
		if (isDead)
			return;



		currentHealth -= dmg;
		if (currentHealth < 0) {
			Death();
		}
	}

	public void Death() {
		Debug.Log ("The target is dead!");
		isDead = true;
		GetComponent <Rigidbody2D>().isKinematic = true;//make bullets go through?
		Destroy (this.gameObject, 2f);

		GameObject newEnemy = Instantiate((GameObject)Resources.Load("EnemyPrefab")) as GameObject;//respawn
	}
}