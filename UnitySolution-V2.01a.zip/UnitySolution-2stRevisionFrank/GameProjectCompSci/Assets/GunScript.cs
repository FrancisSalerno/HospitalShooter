using UnityEngine;
using System.Collections;

public class GunScript : MonoBehaviour
{

		const int LEFTCLICK = 0;

		bool isShooting;
		bool usingKeyboard;
		bool usingJoystick;
		float bulletSpeed = 500f;

		// Use this for initialization
		void Awake ()
		{
			isShooting = false;	
			usingKeyboard = true;
			usingJoystick = false;
		}
	void Start(){
		InvokeRepeating ("Shoot", 0, .05f);
	}
		// Update is called once per frame
	void Shoot(){
		if (isShooting) {
			GameObject bulletInstance = Instantiate(Resources.Load("Bullet")) as GameObject;




			Physics2D.IgnoreCollision (bulletInstance.collider2D , this.gameObject.collider2D);//ignore collisions between this object and bullets






			bulletInstance.transform.position = gameObject.transform.position;
			bulletInstance.transform.eulerAngles = gameObject.transform.eulerAngles;
		//	bulletInstance.AddComponent<WhenToDestroy>();
			
			Vector3 force =  Quaternion.AngleAxis(gameObject.transform.eulerAngles.z,Vector3.forward) * Vector3.right;
			force.Normalize();
			force.x *= bulletSpeed;
			force.y *= bulletSpeed;
			bulletInstance.rigidbody2D.AddForce(force);
		}
	}
	void Update(){ 

		if (usingKeyboard) 
		{
			isShooting = Input.GetMouseButton (LEFTCLICK);
			if (isShooting) 
			{
				//UpdateMouse ();
			}
		} 
		else 
		{			
			float x = Input.GetAxis("RightX");
			float y = Input.GetAxis("RightY");
			isShooting = (x != 0 || y != 0);
			if (isShooting) 
			{
				UpdateJoystick(x,y);
			}
		}
	}
	void UpdateJoystick(float x, float y){
		/*Vector3 playerToJoystick;
		playerToJoystick.x = (x * transform.position.x * 4) - transform.position.x;
		playerToJoystick.y = (y * transform.position.y * 4) - transform.position.y;
		float angleRadians = Mathf.Atan2 (playerToJoystick.y, playerToJoystick.x);

		int angleDegrees = (int)(angleRadians * Mathf.Rad2Deg);
		if (angleDegrees < 0) {
			angleDegrees += 360;
		}
		transform.eulerAngles = new Vector3 (0, 0, angleDegrees);*/
		/*Quaternion newRot = Quaternion.LookRotation(new Vector3(0, 0, x));

		transform.rotation = Quaternion.Lerp(transform.rotation, newRot, Time.deltaTime*10);*/

	}
	/*void UpdateMouse(){
		Vector2 playerToMouse;
		Vector2 player_pos;
		player_pos = this.transform.position;
		Vector3 inputPosition = Input.mousePosition; 
		Vector3 mouseWorldPosition = Camera.mainCamera.ScreenToWorldPoint
			(new Vector3 (Screen.width - inputPosition.x,
			              Screen.height - inputPosition.y, 
			              Camera.main.transform.position.z - 2f));
		mouseWorldPosition.z = 20;
		
		playerToMouse.x = mouseWorldPosition.x - player_pos.x;
		playerToMouse.y = mouseWorldPosition.y - player_pos.y;
		
		float angleRadians = Mathf.Atan2 (playerToMouse.y, playerToMouse.x);
		
		int angleDegrees = (int)(angleRadians * Mathf.Rad2Deg);
		
		if (angleDegrees < 0) {
			angleDegrees += 360;
		}
		
		transform.eulerAngles = new Vector3 (0, 0, angleDegrees);

	}*/
}