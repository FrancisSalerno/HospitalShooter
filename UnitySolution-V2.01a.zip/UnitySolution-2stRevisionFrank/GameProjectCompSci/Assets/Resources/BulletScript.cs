﻿using UnityEngine;
using System.Collections;

public class BulletScript : MonoBehaviour {

	// Use this for initialization
	void Start () {
	
	}

	// Update is called once per frame
	void Update () {
		if (!this.renderer.isVisible){
			Destroy(this.gameObject);
		}
	}

	void OnCollisionEnter2D (Collision2D col){
		Destroy (this.gameObject);
		GameObject.Find(col.gameObject.name).GetComponent<EnemyDescription>().takeDamage(1);//do 1 damage to the object
	}
}
