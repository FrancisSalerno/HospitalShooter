﻿using UnityEngine;
using System.Collections;

public class SimpleFollow : MonoBehaviour {

	// Use this for initialization
	float force = 100;
	void Start () {
		gameObject.rigidbody2D.drag = 2;
	}
	
	// Update is called once per frame
	void Update () {
		if (gameObject.transform.position.x < GameObject.Find ("Player").transform.position.x) {
				rigidbody2D.AddForce (new Vector3 (force, 0, 0));
		} else {
				rigidbody2D.AddForce (new Vector3 (-force, 0, 0));
		}
		if (gameObject.transform.position.y < GameObject.Find ("Player").transform.position.y) {
			rigidbody2D.AddForce (new Vector3 (0, force, 0));
		} else {
			rigidbody2D.AddForce (new Vector3 (0, -force, 0));
		}
	}
}
