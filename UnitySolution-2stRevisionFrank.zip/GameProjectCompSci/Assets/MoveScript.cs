﻿using UnityEngine;
using System.Collections;

public class MoveScript : MonoBehaviour {

	// Use this for initialization
	float baseSpeed = 100f;
	float shiftMultiplier = 2.5f;
	Vector3 player_pos;
	Vector3 player_pos_s;
	void Start () {
	
	}
	
	// Update is called once per frame
	void Update () {
		player_pos = this.transform.position;//grab the position of the player relative to the game world position
		//grab the position of the player relative to the screen
		player_pos_s = Camera.mainCamera.WorldToScreenPoint(transform.position);
		//updateJoystick ();
		updateKeyboard ();
	}
	void updateKeyboard(){
		Vector2 currentForce = new Vector2 (0, 0);
	
		
		if (Input.GetKey (KeyCode.A)) {
			if (player_pos_s.x < 0) {//add 150 to the force, creates a 'bouncing' effect
				currentForce.x += 1.5f * baseSpeed;
			} else {
				currentForce.x -= baseSpeed;
			}
		}
		if (Input.GetKey (KeyCode.D)) {
			
			if (player_pos_s.x > Screen.width) {
				currentForce.x -= 1.5f * baseSpeed;
			} else {
				currentForce.x += baseSpeed;
			}
		}
		if (Input.GetKey (KeyCode.S)) {
			if (player_pos_s.y < 0) {//add 150 to the force, creates a 'bouncing' effect
				currentForce.y += 1.5f * baseSpeed;
			} else {
				currentForce.y -= baseSpeed;
			}
		}
		if (Input.GetKey (KeyCode.W)) {
			if (player_pos_s.y > Screen.height) {
				currentForce.y -= 1.5f * baseSpeed;
			} else {
				currentForce.y += baseSpeed;
			}
		}
		if (Input.GetKey (KeyCode.LeftShift)) {
			currentForce.x *= shiftMultiplier;
			currentForce.y *= shiftMultiplier;
		}
		gameObject.rigidbody2D.AddForce (currentForce , ForceMode2D.Force);
		gameObject.rigidbody2D.drag = 8f;


		Vector3 playerToMouse;
		Vector3 inputPosition = Input.mousePosition; 
		Vector3 mouseWorldPosition = Camera.mainCamera.ScreenToWorldPoint
			(new Vector3 (Screen.width - inputPosition.x,
			              Screen.height - inputPosition.y, 
			              Camera.main.transform.position.z - 2f));
		mouseWorldPosition.z = 20;
		
		playerToMouse.x = mouseWorldPosition.x - player_pos.x;
		playerToMouse.y = mouseWorldPosition.y - player_pos.y;
		
		float angleRadians = Mathf.Atan2 (playerToMouse.y, playerToMouse.x);
		
		int angleDegrees = (int)(angleRadians * Mathf.Rad2Deg);
		
		if (angleDegrees < 0) {
			angleDegrees += 360;
		}
		
		transform.eulerAngles = new Vector3 (0, 0, angleDegrees);
	}
	void updateJoystick(){	
		Vector2 currentForce = new Vector2 (0, 0);
		currentForce.x += Input.GetAxis ("Horizontal") * baseSpeed;
		currentForce.y += Input.GetAxis ("Vertical") * baseSpeed;
		if (Input.GetAxis ("LeftTrigger") != 0) {
			currentForce.x *= shiftMultiplier;
			currentForce.y *= shiftMultiplier;
		}
		gameObject.rigidbody2D.AddForce (currentForce, ForceMode2D.Force);
		gameObject.rigidbody2D.drag = 8f;
	}
}
