﻿using UnityEngine;
using System.Collections;

public class MoveScript : MonoBehaviour {

	// Use this for initialization
	void Start () {
	
	}
	
	// Update is called once per frame
	void Update () {
		if (Input.GetKey (KeyCode.A)) {
			gameObject.rigidbody2D.AddForce(new Vector2(-100f,0),ForceMode2D.Force);}
		if (Input.GetKey (KeyCode.D)) {
			gameObject.rigidbody2D.AddForce(new Vector2(100f,0),ForceMode2D.Force);
		}
		if (Input.GetKey (KeyCode.S)) {
			gameObject.rigidbody2D.AddForce(new Vector2(0,-100f),ForceMode2D.Force);
		}
		if (Input.GetKey (KeyCode.W)) {
			gameObject.rigidbody2D.AddForce(new Vector2(0,100f),ForceMode2D.Force);
		}
		gameObject.rigidbody2D.drag = 8f;
	}
}
