using UnityEngine;
using System.Collections;

public class GunScript : MonoBehaviour
{

	public Camera camera;
		private Vector2 playerToMouse;
		private Vector2 player_pos;
		private float angle;
		public Transform lineSelectorTransform;
		LineRenderer line;
		// Use this for initialization
		void Awake ()
		{
			
		}
	
		// Update is called once per frame
	
	void Update(){ 
		player_pos = this.transform.position;

		Vector3 inputPosition = Input.mousePosition; 
		Vector3 mouseWorldPosition = Camera.mainCamera.ScreenToWorldPoint
			(new Vector3(Screen.width - inputPosition.x, Screen.height - inputPosition.y, Camera.main.transform.position.z - 2f));
		mouseWorldPosition.z = 20;

		playerToMouse.x = mouseWorldPosition.x - player_pos.x;
		playerToMouse.y = mouseWorldPosition.y - player_pos.y;

		float angleRadians = Mathf.Atan2 (playerToMouse.y, playerToMouse.x);

		int angleDegrees = (int)(angleRadians * Mathf.Rad2Deg);

		if (angleDegrees < 0) {
			angleDegrees+=360;
		}

		Debug.Log (angleDegrees);
		transform.eulerAngles = new Vector3 (0,0,angleDegrees);
		//this.gameObject.transform.LookAt (mouseWorldPosition);
	}
}
/*
 * 
 * 
 * 
 * 
		Vector2 playerForward = gameObject.transform.forward;

		float dot = Vector2.Dot (playerToMouse, playerForward);

		dot = dot / (playerToMouse.magnitude * playerForward.magnitude);

		float acos = Mathf.Acos (dot);

		float angle = acos * 180 / Mathf.PI;

		Debug.Log (angle);
*/
	
	// Use this for initialization


	