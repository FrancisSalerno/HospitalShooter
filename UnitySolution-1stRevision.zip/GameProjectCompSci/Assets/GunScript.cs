using UnityEngine;
using System.Collections;

public class GunScript : MonoBehaviour
{

		const int LEFTCLICK = 0;
		private Vector2 playerToMouse;
		private Vector2 player_pos;
		bool isShooting;
		float bulletSpeed = 5000f;

		// Use this for initialization
		void Awake ()
		{
			isShooting = false;	
		}
	void Start(){
		InvokeRepeating ("Shoot", 0, .05f);
	}
	
		// Update is called once per frame

	void Shoot(){
		if (isShooting) {
			GameObject bulletInstance = (GameObject)Instantiate(Resources.Load("Bullet", typeof(GameObject))) as GameObject;
			
			bulletInstance.transform.position = gameObject.transform.position;
			bulletInstance.transform.eulerAngles = gameObject.transform.eulerAngles;

			
			Vector3 force =  Quaternion.AngleAxis(gameObject.transform.eulerAngles.z,Vector3.forward) * Vector3.right;
			force.Normalize();
			force.x *= bulletSpeed;
			force.y *= bulletSpeed;
			bulletInstance.rigidbody2D.AddForce(force);
		}

	}
	void Update(){ 


		isShooting = Input.GetMouseButton (LEFTCLICK);
						
		if (isShooting) {
				player_pos = this.transform.position;

				Vector3 inputPosition = Input.mousePosition; 
				Vector3 mouseWorldPosition = Camera.mainCamera.ScreenToWorldPoint
								(new Vector3 (Screen.width - inputPosition.x,
					              Screen.height - inputPosition.y, 
					              Camera.main.transform.position.z - 2f));
				mouseWorldPosition.z = 20;

				playerToMouse.x = mouseWorldPosition.x - player_pos.x;
				playerToMouse.y = mouseWorldPosition.y - player_pos.y;

				float angleRadians = Mathf.Atan2 (playerToMouse.y, playerToMouse.x);

				int angleDegrees = (int)(angleRadians * Mathf.Rad2Deg);

				if (angleDegrees < 0) {
						angleDegrees += 360;
				}

				transform.eulerAngles = new Vector3 (0, 0, angleDegrees);

				
		}

	}
}