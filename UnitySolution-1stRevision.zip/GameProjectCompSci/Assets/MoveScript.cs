﻿using UnityEngine;
using System.Collections;

public class MoveScript : MonoBehaviour {

	// Use this for initialization
	void Start () {
	
	}
	
	// Update is called once per frame
	void Update () {
		Vector2 currentForce = new Vector2 (0, 0);

		if (Input.GetKey (KeyCode.A)) {
			//gameObject.rigidbody2D.AddForce(new Vector2(-100f,0),ForceMode2D.Force);
			currentForce.x -= 100f;
		}
		if (Input.GetKey (KeyCode.D)) {
		//	gameObject.rigidbody2D.AddForce(new Vector2(100f,0),ForceMode2D.Force);
			currentForce.x += 100f;
		}
		if (Input.GetKey (KeyCode.S)) {
			currentForce.y -= 100f;
		}
		if (Input.GetKey (KeyCode.W)) {
			currentForce.y += 100f;
		}

		if (Input.GetKey (KeyCode.LeftShift)) {
			currentForce.x *= 1.5f;
			currentForce.y *= 1.5f;
		}
		gameObject.rigidbody2D.AddForce (currentForce, ForceMode2D.Force);
		gameObject.rigidbody2D.drag = 8f;
	}
}
