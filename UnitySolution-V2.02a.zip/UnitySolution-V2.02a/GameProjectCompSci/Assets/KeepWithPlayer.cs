﻿using UnityEngine;
using System.Collections;

public class KeepWithPlayer : MonoBehaviour {

	// Use this for initialization
	void Start () {
	}
	
	// Update is called once per frame
	void Update () {
		this.transform.position = GameObject.Find ("Player").transform.position; 
	}
}
