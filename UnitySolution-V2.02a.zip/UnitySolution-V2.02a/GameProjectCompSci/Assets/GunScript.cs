using UnityEngine;
using System.Collections;

public class GunScript : MonoBehaviour
{

		const int LEFTCLICK = 0;

		bool isShooting;
		bool usingKeyboard;
		bool usingJoystick;
		float bulletSpeed = 600f;

		AudioSource gunSource;

		// Use this for initialization
		void Awake ()
		{
			gunSource = gameObject.AddComponent<AudioSource>();
			gunSource.clip = Resources.Load("GunShoot") as AudioClip;
		gunSource.volume = .2f;
			isShooting = false;	
			usingKeyboard = true;
			usingJoystick = false;
		}
	void Start(){
			InvokeRepeating ("Shoot", 0.0001f, .08f);		//Invoke repeating bug. http://answers.unity3d.com/questions/465034/invokerepeating-doesnt-really-care-about-repeat-ti.html Source		
															//Second argument can't be 0
	}
		// Update is called once per frame
	void Shoot(){
		if (isShooting) {
		
			GameObject bulletInstance = Instantiate(Resources.Load("Bullet")) as GameObject;
	//		bulletInstance.AddComponent<WhenToDestroy>();
			gunSource.Play();


			Physics2D.IgnoreCollision (bulletInstance.collider2D , this.gameObject.collider2D);//ignore collisions between this object and bullets
			bulletInstance.transform.position = gameObject.transform.position;
			bulletInstance.transform.eulerAngles = gameObject.transform.eulerAngles;
	
			
			Vector3 force =  Quaternion.AngleAxis(gameObject.transform.eulerAngles.z,Vector3.forward) * Vector3.right;
			force.Normalize();
	
			force.x *= bulletSpeed;
			force.y *= bulletSpeed;
			bulletInstance.rigidbody2D.AddForce(force);
			bulletInstance.rigidbody2D.velocity += gameObject.rigidbody2D.velocity;
		}
	}
	void Update(){ 

		if (usingKeyboard) 
		{
			isShooting = Input.GetMouseButton (LEFTCLICK);
			if (isShooting) 
			{

				//UpdateMouse ();
			}
		} 
		else 
		{			
			float x = Input.GetAxis("RightX");
			float y = Input.GetAxis("RightY");

			UpdateJoystick(x,y);
			isShooting = (Mathf.Abs(x) >0.05 || Mathf.Abs(y) > 0.05);
		//	if (isShooting);
			

		
		}
	}
	void UpdateJoystick(float x, float y){
		// find vector to move

		//Assumes you're looking down the z axis
	

		//Assumes you're looking down the z axis and that you are looking down on the avatar
		//transform.LookAt(transform.position + new Vector3(0, x, y), -Vector3.right);
		Vector3 newPoint = new Vector3 (x * 1.5f * transform.position.x, y * 1.5f* transform.position.y, 0);
		Vector3 playerToPoint = new Vector3 ();

		playerToPoint.x = newPoint.x - transform.position.x;
		playerToPoint.y = newPoint.y - transform.position.y;

		playerToPoint.Normalize ();
	

		float angleRadians = Mathf.Atan2 (playerToPoint.y, playerToPoint.x);

		int angleDegrees = (int)(angleRadians * Mathf.Rad2Deg);

		angleDegrees += 360;
		if (angleDegrees < 0) {
			angleDegrees+= 360;
		}
		transform.eulerAngles = new Vector3 (0, 0, angleDegrees);

	/*	float angle = x / y;
		Debug.Log (angle);
		float rad = Mathf.Atan (angle);
		float degree = Mathf.Rad2Deg * rad;

		if (degree < 0) {
			degree += 360;
		}
		transform.eulerAngles = new Vector3 (0, 0, degree);*/
		

	}
	/*void UpdateMouse(){
		Vector2 playerToMouse;
		Vector2 player_pos;
		player_pos = this.transform.position;
		Vector3 inputPosition = Input.mousePosition; 
		Vector3 mouseWorldPosition = Camera.mainCamera.ScreenToWorldPoint
			(new Vector3 (Screen.width - inputPosition.x,
			              Screen.height - inputPosition.y, 
			              Camera.main.transform.position.z - 2f));
		mouseWorldPosition.z = 20;
		
		playerToMouse.x = mouseWorldPosition.x - player_pos.x;
		playerToMouse.y = mouseWorldPosition.y - player_pos.y;
		
		float angleRadians = Mathf.Atan2 (playerToMouse.y, playerToMouse.x);
		
		int angleDegrees = (int)(angleRadians * Mathf.Rad2Deg);
		
		if (angleDegrees < 0) {
			angleDegrees += 360;
		}
		
		transform.eulerAngles = new Vector3 (0, 0, angleDegrees);

	}*/
}