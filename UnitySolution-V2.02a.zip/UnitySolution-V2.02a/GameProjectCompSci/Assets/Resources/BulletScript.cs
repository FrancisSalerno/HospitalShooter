﻿using UnityEngine;
using System.Collections;

public class BulletScript : MonoBehaviour {

	// Use this for initialization
	void Start () {
	
	}

	// Update is called once per frame
	void Update () {
	/*	if (!this.renderer.isVisible){						//The renderer.isVisible check is sometimes buggy. The bullets are randomly not visible, and get destroyed right away.
			//Destroy(this.gameObject);
		}*/
		Vector2 screenPosition = Camera.main.WorldToScreenPoint(transform.position);			//Instead lets check if the bullet left the screen!
		if (screenPosition.y > Screen.height || screenPosition.y < 0 || screenPosition.x > Screen.width || screenPosition.x < 0)
			Destroy(this.gameObject);
	}

	void OnCollisionEnter2D (Collision2D col){
		if (col.gameObject != null)
			col.gameObject.GetComponent<EnemyDescription> ().takeDamage (1);		//Do 1 damage to the enemy collided

		if (gameObject != null)
		Destroy (this.gameObject);
		//Null check the object
	



		//No need for gameobject find, we already have a handle on the game object from its collider

		//GameObject.Find(col.gameObject.name).GetComponent<EnemyDescription>().takeDamage(1);//do 1 damage to the object			
	}
}
