﻿using UnityEngine;
using System.Collections;

public class EnemyInstanceHandle : MonoBehaviour {

	int currentEnemies = 2;
	int maxEnemies = 10;
	void Start () {
		InvokeRepeating ("Spawn", .0001f, 5);
	}
	
	public void Spawn(){
		//Debug.Log (currentEnemies);
		if (currentEnemies < maxEnemies) {
			IncrementEnemy ();
				GameObject newEnemy = Instantiate ((GameObject)Resources.Load ("EnemyPrefab")) as GameObject;//respawn
		}
	
	}
	// Update is called once per frame
	void Update () {
		
	}
	public void IncrementEnemy(){
		currentEnemies ++;
	}
	public void DecrementEnemy(){
		currentEnemies --;
	}
}
