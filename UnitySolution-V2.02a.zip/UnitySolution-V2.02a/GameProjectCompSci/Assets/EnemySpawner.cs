﻿using UnityEngine;
using System.Collections;

public class EnemySpawn : MonoBehaviour {

	// Use this for initialization
	int currentEnemies = 0;
	int maxEnemies = 10;
	void Start () {
		InvokeRepeating ("Spawn", .0001f, 5);
	}
	
	void Spawn(){
		GameObject newEnemy = Instantiate((GameObject)Resources.Load("EnemyPrefab")) as GameObject;//respawn
		GameObject.Find ("EnemySpawner").GetComponent<EnemySpawn> ().IncrementEnemy ();
	}
	// Update is called once per frame
	void Update () {
	
	}
	public void IncrementEnemy(){
		currentEnemies ++;
	}
	public void DecrementEnemy(){
		currentEnemies --;
	}
}
