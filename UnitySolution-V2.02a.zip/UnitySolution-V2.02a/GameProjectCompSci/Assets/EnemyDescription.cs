﻿using UnityEngine;
using System.Collections;

public class EnemyDescription : MonoBehaviour {
	public int startingHealth = 10;
	public int damage = 1;
	private int currentHealth;
	public bool isDead;
	AudioSource deathSound;


	void Start(){
		renderer.material.color = Color.green;
	}
	void Awake() {
	
		//renderer.material.color = Color.green;
		deathSound = gameObject.AddComponent<AudioSource>();
		deathSound.clip = Resources.Load("enemydead") as AudioClip;
		deathSound.volume = .5f;
		currentHealth = startingHealth;
		isDead = false;
	}

	public void takeDamage(int dmg) {
		//do nothing if isDead = true
		if (isDead)
			return;
		ChangeColor ();


		currentHealth -= dmg;
		if (currentHealth < 0) {
			Death();
		}
	}

	void ChangeColor(){
		Color current = renderer.material.color;
		renderer.material.color = current + new Color (.2f, -.1f, 0);

	}

	public void Death() {
	
		GameObject.Find ("EnemySpawner").GetComponent<EnemyInstanceHandle> ().DecrementEnemy ();
		GameObject.Find ("EnemySpawner").GetComponent<EnemyInstanceHandle> ().Spawn ();
		deathSound.Play ();
		renderer.material.color = Color.grey;
		Debug.Log ("The target is dead!");
		isDead = true;
		GetComponent <Rigidbody2D>().isKinematic = true;//make bullets go through?
		Destroy (this.gameObject, 2f);

		//GameObject newEnemy = Instantiate((GameObject)Resources.Load("EnemyPrefab")) as GameObject;//respawn
	}
}